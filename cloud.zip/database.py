import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Dict, List, Optional


class IntrusionDB:
    def __init__(self, db_path: str):
        self.db_path = db_path
        parent = os.path.dirname(os.path.abspath(db_path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        self.init_db()

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def init_db(self) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS intrusions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    camera_id TEXT NOT NULL,
                    camera_name TEXT,
                    start_ts TEXT NOT NULL,
                    end_ts TEXT,
                    duration_seconds REAL,
                    snapshot_path TEXT,
                    video_path TEXT,
                    status TEXT NOT NULL DEFAULT 'active'
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_intrusions_camera ON intrusions(camera_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_intrusions_start ON intrusions(start_ts)")

    def start_intrusion(self, camera_id: str, camera_name: str, snapshot_path: str, video_path: str) -> int:
        now = datetime.now().isoformat(timespec="seconds")
        with self.connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO intrusions(camera_id, camera_name, start_ts, snapshot_path, video_path, status)
                VALUES (?, ?, ?, ?, ?, 'active')
                """,
                (camera_id, camera_name, now, snapshot_path, video_path),
            )
            return int(cur.lastrowid)

    def end_intrusion(self, intrusion_id: int) -> None:
        end_ts = datetime.now()
        with self.connect() as conn:
            row = conn.execute("SELECT start_ts FROM intrusions WHERE id = ?", (intrusion_id,)).fetchone()
            if not row:
                return
            start_ts = datetime.fromisoformat(row["start_ts"])
            duration = max(0.0, (end_ts - start_ts).total_seconds())
            conn.execute(
                """
                UPDATE intrusions
                SET end_ts = ?, duration_seconds = ?, status = 'ended'
                WHERE id = ?
                """,
                (end_ts.isoformat(timespec="seconds"), duration, intrusion_id),
            )


    def end_active_for_camera(self, camera_id: str) -> None:
        """Close any active rows for a camera, used when the user manually stops a camera."""
        end_ts = datetime.now()
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT id, start_ts FROM intrusions WHERE camera_id = ? AND status = 'active'",
                (camera_id,),
            ).fetchall()
            for row in rows:
                start_ts = datetime.fromisoformat(row["start_ts"])
                duration = max(0.0, (end_ts - start_ts).total_seconds())
                conn.execute(
                    """
                    UPDATE intrusions
                    SET end_ts = ?, duration_seconds = ?, status = 'ended'
                    WHERE id = ?
                    """,
                    (end_ts.isoformat(timespec="seconds"), duration, row["id"]),
                )

    def end_all_active(self) -> None:
        """Close stale active rows from a previous process run."""
        end_ts = datetime.now()
        with self.connect() as conn:
            rows = conn.execute("SELECT id, start_ts FROM intrusions WHERE status = 'active'").fetchall()
            for row in rows:
                start_ts = datetime.fromisoformat(row["start_ts"])
                duration = max(0.0, (end_ts - start_ts).total_seconds())
                conn.execute(
                    """
                    UPDATE intrusions
                    SET end_ts = ?, duration_seconds = ?, status = 'ended'
                    WHERE id = ?
                    """,
                    (end_ts.isoformat(timespec="seconds"), duration, row["id"]),
                )

    def list_intrusions(self, limit: int = 100, camera_id: Optional[str] = None) -> List[Dict[str, Any]]:
        limit = max(1, min(limit, 500))
        with self.connect() as conn:
            if camera_id:
                rows = conn.execute(
                    """
                    SELECT * FROM intrusions
                    WHERE camera_id = ?
                    ORDER BY id DESC
                    LIMIT ?
                    """,
                    (camera_id, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM intrusions ORDER BY id DESC LIMIT ?",
                    (limit,),
                ).fetchall()
            return [dict(row) for row in rows]

    def stats(self) -> Dict[str, Any]:
        with self.connect() as conn:
            row = conn.execute(
                """
                SELECT
                    COUNT(*) AS total_intrusions,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_intrusions,
                    MAX(id) AS latest_intrusion_id
                FROM intrusions
                """
            ).fetchone()
            return {
                "total_intrusions": int(row["total_intrusions"] or 0),
                "active_intrusions": int(row["active_intrusions"] or 0),
                "latest_intrusion_id": row["latest_intrusion_id"],
            }
