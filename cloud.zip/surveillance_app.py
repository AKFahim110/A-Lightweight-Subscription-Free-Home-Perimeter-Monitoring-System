import argparse
import os
import queue
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np
import requests
import supervision as sv
import uvicorn
import yaml
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel
from ultralytics import YOLO

try:
    import torch
except Exception:  # Torch is installed with Ultralytics in normal installs, but keep startup resilient.
    torch = None

from database import IntrusionDB


class CameraPatch(BaseModel):
    enabled: Optional[bool] = None
    roi_config: Optional[str] = None
    model: Optional[str] = None
    source: Optional[str] = None


class RoiSaveRequest(BaseModel):
    name: str
    points: List[List[int]]


def load_yaml(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def save_yaml(path: str, data: Dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False)


def safe_name(name: str) -> str:
    cleaned = "".join(ch for ch in name if ch.isalnum() or ch in ("-", "_", "."))
    if not cleaned:
        raise ValueError("Name must contain at least one safe filename character.")
    if not cleaned.endswith((".yaml", ".yml")):
        cleaned += ".yaml"
    return cleaned


def now_monotonic() -> float:
    return time.perf_counter()


class TelegramNotifier:
    """Non-blocking Telegram sender so network calls never stall inference or the UI."""

    def __init__(self, settings: Dict[str, Any]):
        self.enabled = bool(settings.get("enabled", False))
        self.token = str(settings.get("token", "")).strip()
        self.chat_id = str(settings.get("chat_id", "")).strip()
        self.jobs: "queue.Queue[Tuple[str, Optional[str]]]" = queue.Queue(maxsize=32)
        self.thread = threading.Thread(target=self._loop, name="telegram-notifier", daemon=True)
        self.thread.start()

    def send(self, message: str, photo_path: Optional[str] = None) -> None:
        if not self.enabled or not self.token or not self.chat_id:
            return
        try:
            self.jobs.put_nowait((message, photo_path))
        except queue.Full:
            print("[telegram] notification queue full; dropped alert")

    def _loop(self) -> None:
        while True:
            message, photo_path = self.jobs.get()
            try:
                msg_url = f"https://api.telegram.org/bot{self.token}/sendMessage"
                requests.post(msg_url, data={"chat_id": self.chat_id, "text": message}, timeout=5)
                if photo_path and os.path.exists(photo_path):
                    photo_url = f"https://api.telegram.org/bot{self.token}/sendPhoto"
                    with open(photo_path, "rb") as photo:
                        requests.post(photo_url, data={"chat_id": self.chat_id}, files={"photo": photo}, timeout=10)
            except requests.RequestException as exc:
                print(f"[telegram] failed to send alert: {exc}")
            finally:
                self.jobs.task_done()


class CameraWorker:
    """
    One camera = one background worker.

    Important performance choices:
    - The web route never runs model inference; it only returns the latest encoded JPEG.
    - Ultralytics is explicitly told to use CUDA when configured.
    - Inference FPS and stream FPS are separate. You can stream smoothly without running YOLO
      on every decoded frame.
    - The dashboard does not recreate <img> streams on each refresh, so controls remain snappy.
    """

    def __init__(self, camera_cfg: Dict[str, Any], app_cfg: Dict[str, Any], models_cfg: Dict[str, Any], db: IntrusionDB, notifier: TelegramNotifier):
        self.cfg = camera_cfg
        self.app_cfg = app_cfg
        self.models_cfg = models_cfg
        self.db = db
        self.notifier = notifier
        self.lock = threading.Lock()
        self.frame_condition = threading.Condition(self.lock)
        self.thread: Optional[threading.Thread] = None
        self.stop_event = threading.Event()
        self.cap: Optional[cv2.VideoCapture] = None
        self.capture_lock = threading.Lock()
        self.latest_jpeg: Optional[bytes] = None
        self.frame_seq = 0
        self.status: Dict[str, Any] = {
            "running": False,
            "active_intrusions": 0,
            "last_error": None,
            "latest_intrusion_id": None,
            "fps_capture": 0.0,
            "fps_infer": 0.0,
            "fps_stream": 0.0,
            "device": "unknown",
        }

    @property
    def camera_id(self) -> str:
        return self.cfg["id"]

    @property
    def camera_name(self) -> str:
        return self.cfg.get("name", self.camera_id)

    def update_cfg(self, patch: Dict[str, Any]) -> None:
        restart_needed = False
        for key, value in patch.items():
            if value is None:
                continue
            if key in {"roi_config", "model", "source"} and self.cfg.get(key) != value:
                restart_needed = self.is_running()
            self.cfg[key] = value
        if restart_needed:
            self.stop()
            self.start()

    def is_running(self) -> bool:
        return bool(self.thread and self.thread.is_alive())

    def start(self) -> None:
        if self.is_running():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run, name=f"camera-{self.camera_id}", daemon=True)
        self.thread.start()

    def stop(self) -> None:
        """Stop this camera's entire backend pipeline: capture, inference, logging, and recording."""
        self.stop_event.set()

        # Unblock cap.read() quickly, especially for RTSP/IP cameras where reads may block.
        with self.capture_lock:
            if self.cap is not None:
                try:
                    self.cap.release()
                except Exception:
                    pass

        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=6)
        self.thread = None
        with self.frame_condition:
            self.status["running"] = False
            self.status["active_intrusions"] = 0
            self.status["fps_capture"] = 0.0
            self.status["fps_infer"] = 0.0
            self.status["fps_stream"] = 0.0
            self.latest_jpeg = None
            self.frame_seq += 1
            self.frame_condition.notify_all()

    def get_frame(self) -> Optional[bytes]:
        with self.lock:
            return self.latest_jpeg

    def get_status(self) -> Dict[str, Any]:
        with self.lock:
            return dict(self.status)

    def wait_for_frame(self, last_seq: int, timeout: float = 1.0) -> Tuple[Optional[bytes], int]:
        with self.frame_condition:
            if self.frame_seq == last_seq and not self.stop_event.is_set():
                self.frame_condition.wait(timeout=timeout)
            return self.latest_jpeg, self.frame_seq

    def _load_roi(self) -> np.ndarray:
        roi_path = self.cfg["roi_config"]
        data = load_yaml(roi_path)
        points = data.get("roi_polygon")
        if not points or len(points) < 3:
            raise ValueError(f"Invalid ROI config {roi_path}; expected roi_polygon with at least 3 points.")
        return np.array(points, dtype=np.int32)

    def _model_cfg(self) -> Dict[str, Any]:
        model_key = self.cfg.get("model")
        model_cfg = self.models_cfg.get(model_key)
        if not model_cfg:
            raise ValueError(f"Unknown model config: {model_key}")
        return model_cfg

    def _resolve_device(self, model_cfg: Dict[str, Any]) -> str:
        requested = str(model_cfg.get("device", self.app_cfg.get("device", "auto"))).lower()
        if requested == "auto":
            if torch is not None and torch.cuda.is_available():
                return "0"
            return "cpu"
        if requested in {"cuda", "gpu"}:
            return "0"
        return requested

    def _load_model(self, model_cfg: Dict[str, Any]) -> YOLO:
        if torch is not None and torch.cuda.is_available():
            torch.backends.cudnn.benchmark = True
            try:
                torch.set_float32_matmul_precision("high")
            except Exception:
                pass
        model = YOLO(model_cfg["path"])
        device = self._resolve_device(model_cfg)
        # .to() is ignored by TensorRT engines but helps PyTorch weights land on CUDA before first track call.
        try:
            model.to(device)
        except Exception:
            pass
        try:
            model.fuse()
        except Exception:
            pass
        return model

    def _open_capture(self) -> cv2.VideoCapture:
        source = self.cfg["source"]
        # CAP_FFMPEG generally behaves better for RTSP/files and supports small buffers on many builds.
        cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG)
        if not cap.isOpened():
            cap = cv2.VideoCapture(source)
        try:
            cap.set(cv2.CAP_PROP_BUFFERSIZE, int(self.app_cfg.get("capture_buffer_size", 1)))
        except Exception:
            pass
        return cap

    def _encode_jpeg(self, frame: np.ndarray) -> Optional[bytes]:
        quality = int(self.app_cfg.get("jpeg_quality", 70))
        ok, buffer = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
        return buffer.tobytes() if ok else None

    def _run(self) -> None:
        out_video = None
        active_intrusion_id = None
        is_alerted = False
        empty_frames = 0
        cap: Optional[cv2.VideoCapture] = None

        try:
            polygon = self._load_roi()
            model_cfg = self._model_cfg()
            model = self._load_model(model_cfg)
            device = self._resolve_device(model_cfg)
            zone = sv.PolygonZone(polygon=polygon)
            box_annotator = sv.BoxAnnotator(thickness=2)
            cap = self._open_capture()
            with self.capture_lock:
                self.cap = cap
            if not cap.isOpened():
                raise RuntimeError(f"Could not open source: {self.cfg['source']}")

            source_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1280)
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 720)
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")

            patience_frames = int(self.app_cfg.get("patience_frames", 30))
            process_fps = float(self.cfg.get("process_fps", self.app_cfg.get("process_fps", 12)))
            stream_fps = float(self.cfg.get("stream_fps", self.app_cfg.get("stream_fps", 10)))
            record_fps = float(self.cfg.get("record_fps", self.app_cfg.get("record_fps", min(source_fps, 15))))
            imgsz = int(model_cfg.get("imgsz", self.app_cfg.get("imgsz", 640)))
            half = bool(model_cfg.get("half", self.app_cfg.get("half", device != "cpu"))) and device != "cpu"
            use_tracker = bool(model_cfg.get("tracker", ""))
            tracker = model_cfg.get("tracker", "bytetrack.yaml")
            infer_period = 1.0 / max(process_fps, 1.0)
            stream_period = 1.0 / max(stream_fps, 1.0)
            record_period = 1.0 / max(record_fps, 1.0)
            next_infer = 0.0
            next_stream = 0.0
            next_record = 0.0

            intruder_dir = self.app_cfg.get("intruder_dir", "intruder")
            videos_dir = self.app_cfg.get("videos_dir", "videos")
            os.makedirs(intruder_dir, exist_ok=True)
            os.makedirs(videos_dir, exist_ok=True)

            detections = sv.Detections.empty()
            people_in_zone = 0
            frame_count = infer_count = stream_count = 0
            stat_t = now_monotonic()

            # Warm up CUDA/TensorRT outside the hot loop so first stream hit doesn't freeze the UI.
            dummy = np.zeros((height, width, 3), dtype=np.uint8)
            try:
                model.predict(dummy, device=device, imgsz=imgsz, half=half, classes=model_cfg.get("classes", [0]), conf=float(model_cfg.get("conf", 0.25)), verbose=False)
            except Exception:
                pass

            with self.lock:
                self.status.update({"running": True, "last_error": None, "device": device})

            while not self.stop_event.is_set():
                ret, frame = cap.read()
                if not ret:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    time.sleep(0.03)
                    continue

                frame_count += 1
                t = now_monotonic()

                if t >= next_infer:
                    next_infer = t + infer_period
                    infer_count += 1
                    if use_tracker:
                        result = model.track(
                            frame,
                            classes=model_cfg.get("classes", [0]),
                            persist=True,
                            tracker=tracker,
                            conf=float(model_cfg.get("conf", 0.25)),
                            imgsz=imgsz,
                            device=device,
                            half=half,
                            verbose=False,
                        )[0]
                    else:
                        result = model.predict(
                            frame,
                            classes=model_cfg.get("classes", [0]),
                            conf=float(model_cfg.get("conf", 0.25)),
                            imgsz=imgsz,
                            device=device,
                            half=half,
                            verbose=False,
                        )[0]
                    detections = sv.Detections.from_ultralytics(result)
                    in_zone = zone.trigger(detections=detections)
                    people_in_zone = int(np.sum(in_zone)) if len(in_zone) else 0

                    if people_in_zone > 0:
                        empty_frames = 0
                        if not is_alerted:
                            is_alerted = True
                            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                            snapshot_path = os.path.join(intruder_dir, f"{self.camera_id}_{timestamp}.jpg")
                            video_path = os.path.join(videos_dir, f"{self.camera_id}_{timestamp}.mp4")
                            cv2.imwrite(snapshot_path, frame, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
                            out_video = cv2.VideoWriter(video_path, fourcc, record_fps, (width, height))
                            active_intrusion_id = self.db.start_intrusion(self.camera_id, self.camera_name, snapshot_path, video_path)
                            self.notifier.send(f"SECURITY ALERT: intrusion detected on {self.camera_name}", snapshot_path)
                            with self.lock:
                                self.status["latest_intrusion_id"] = active_intrusion_id
                        with self.lock:
                            self.status["active_intrusions"] = people_in_zone
                    else:
                        if is_alerted:
                            empty_frames += 1
                            if empty_frames >= patience_frames:
                                is_alerted = False
                                empty_frames = 0
                                if active_intrusion_id is not None:
                                    self.db.end_intrusion(active_intrusion_id)
                                active_intrusion_id = None
                                if out_video is not None:
                                    out_video.release()
                                    out_video = None
                                with self.lock:
                                    self.status["active_intrusions"] = 0

                color = (0, 0, 255) if is_alerted else (0, 255, 255)
                annotated = box_annotator.annotate(scene=frame.copy(), detections=detections)
                cv2.polylines(annotated, [polygon], isClosed=True, color=color, thickness=3)
                cv2.putText(annotated, self.camera_name, (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)

                if out_video is not None and t >= next_record:
                    next_record = t + record_period
                    out_video.write(annotated)

                if t >= next_stream:
                    next_stream = t + stream_period
                    jpeg = self._encode_jpeg(annotated)
                    if jpeg:
                        stream_count += 1
                        with self.frame_condition:
                            self.latest_jpeg = jpeg
                            self.frame_seq += 1
                            self.frame_condition.notify_all()

                if t - stat_t >= 2.0:
                    elapsed = t - stat_t
                    with self.lock:
                        self.status["fps_capture"] = round(frame_count / elapsed, 1)
                        self.status["fps_infer"] = round(infer_count / elapsed, 1)
                        self.status["fps_stream"] = round(stream_count / elapsed, 1)
                    frame_count = infer_count = stream_count = 0
                    stat_t = t

            if cap is not None:
                cap.release()
            with self.capture_lock:
                if self.cap is cap:
                    self.cap = None
        except Exception as exc:
            with self.lock:
                self.status["last_error"] = str(exc)
            print(f"[{self.camera_id}] error: {exc}")
        finally:
            if cap is not None:
                try:
                    cap.release()
                except Exception:
                    pass
            with self.capture_lock:
                if self.cap is cap:
                    self.cap = None
            if out_video is not None:
                out_video.release()
            if active_intrusion_id is not None:
                self.db.end_intrusion(active_intrusion_id)
            with self.lock:
                self.status["running"] = False
                self.status["active_intrusions"] = 0
                self.frame_condition.notify_all()


DASHBOARD_HTML = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Surveillance Dashboard</title>
  <style>
    body { margin:0; font-family: system-ui, Arial, sans-serif; background:#0d1117; color:#e6edf3; }
    header { padding:18px 24px; background:#161b22; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #30363d; }
    nav a { color:#8b949e; margin-left:18px; text-decoration:none; } nav a:hover { color:white; }
    main { padding:24px; }
    .grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(420px, 1fr)); gap:20px; }
    .card { background:#161b22; border:1px solid #30363d; border-radius:16px; padding:18px; box-shadow: 0 12px 30px rgba(0,0,0,.2); }
    .stream { width:100%; border-radius:12px; background:#010409; border:1px solid #30363d; min-height:240px; object-fit:contain; }
    .row { display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin:10px 0; }
    button, select, input { background:#21262d; color:#e6edf3; border:1px solid #30363d; border-radius:8px; padding:9px 11px; }
    button.primary { background:#238636; border-color:#2ea043; } button.danger { background:#da3633; border-color:#f85149; }
    .pill { padding:6px 10px; border-radius:999px; background:#30363d; }
    .alert { background:#5a1e1e; color:#ffb4b4; } .ok { background:#183a24; color:#a5f3b9; }
    .muted { color:#8b949e; font-size:.9rem; }
  </style>
</head>
<body>
<header><strong>Security Surveillance Dashboard</strong><nav><a href="/">Dashboard</a><a href="/configs">Configs</a><a href="/logs">Logs</a></nav></header>
<main>
  <section class="card row"><span id="globalStatus" class="pill ok">Loading...</span><span id="globalTotals"></span></section>
  <section id="cameraGrid" class="grid"></section>
</main>
<script>
let knownCards = new Set();
async function api(url, options={}) { const r = await fetch(url, options); if(!r.ok) throw new Error(await r.text()); return await r.json(); }
async function patchCamera(id, patch) {
  await api(`/api/cameras/${id}`, {method:'PATCH', headers:{'Content-Type':'application/json'}, body:JSON.stringify(patch)});
  await refresh(false);
}
function setOptions(select, values, selected) {
  const current = Array.from(select.options).map(o => o.value).join('|') + '::' + select.value;
  const next = values.join('|') + '::' + selected;
  if (current === next) return;
  select.innerHTML = values.map(v => `<option value="${v}" ${v===selected?'selected':''}>${v}</option>`).join('');
}
function createCard(cam) {
  const card = document.createElement('div');
  card.className = 'card';
  card.id = `card-${cam.id}`;
  card.innerHTML = `<h2 class="name"></h2>
    <div class="row"><span class="state pill"></span><span class="active pill"></span><span class="perf pill"></span></div>
    <p class="error" style="color:#ffb4b4"></p>
    <img class="stream" alt="Camera stopped" />
    <div class="row">
      <button class="primary start">Start Camera</button><button class="danger stop">Stop Camera</button>
      <label>ROI <select class="roi"></select></label>
      <label>Model <select class="model"></select></label>
    </div>
    <div class="row"><input class="source" style="flex:1"/><button class="sourceBtn">Update Source</button></div>
    <div class="muted">Start attaches the stream and starts backend detection. Stop detaches the stream and stops capture, inference, logging, and recording for this camera.</div>`;
  card.querySelector('.start').onclick = async () => {
    await patchCamera(cam.id, {enabled:true});
    const img = card.querySelector('.stream');
    img.src = `/api/cameras/${cam.id}/stream?t=${Date.now()}`;
    img.alt = 'Live stream';
  };
  card.querySelector('.stop').onclick = async () => {
    const img = card.querySelector('.stream');
    img.removeAttribute('src');
    img.alt = 'Camera stopped';
    await patchCamera(cam.id, {enabled:false});
  };
  card.querySelector('.roi').onchange = e => patchCamera(cam.id, {roi_config:e.target.value});
  card.querySelector('.model').onchange = e => patchCamera(cam.id, {model:e.target.value});
  card.querySelector('.sourceBtn').onclick = () => patchCamera(cam.id, {source:card.querySelector('.source').value});
  document.getElementById('cameraGrid').appendChild(card);
  knownCards.add(cam.id);
  return card;
}
function updateCard(cam, data) {
  const card = document.getElementById(`card-${cam.id}`) || createCard(cam);
  card.querySelector('.name').textContent = cam.name;
  const state = card.querySelector('.state');
  state.textContent = cam.status.running ? 'Running' : 'Stopped';
  state.className = 'state pill ' + (cam.status.running ? 'ok' : 'alert');
  card.querySelector('.start').disabled = !!cam.status.running;
  card.querySelector('.stop').disabled = !cam.status.running;
  card.querySelector('.active').textContent = `Active: ${cam.status.active_intrusions}`;
  card.querySelector('.perf').textContent = `GPU ${cam.status.device || '?'} | infer ${cam.status.fps_infer || 0} fps | stream ${cam.status.fps_stream || 0} fps`;
  card.querySelector('.error').textContent = cam.status.last_error || '';
  setOptions(card.querySelector('.roi'), data.roi_configs, cam.roi_config);
  setOptions(card.querySelector('.model'), data.models, cam.model);
  const source = card.querySelector('.source');
  if (document.activeElement !== source && source.value !== cam.source) source.value = cam.source;
}
async function refresh() {
  const data = await api('/api/dashboard');
  const gs = document.getElementById('globalStatus');
  gs.textContent = data.stats.active_intrusions > 0 ? 'ALERT' : 'SECURE';
  gs.className = 'pill ' + (data.stats.active_intrusions > 0 ? 'alert' : 'ok');
  document.getElementById('globalTotals').textContent = `${data.stats.active_intrusions} active / ${data.stats.total_intrusions} total events`;
  data.cameras.forEach(cam => updateCard(cam, data));
}
refresh(); setInterval(refresh, 1200);
</script>
</body>
</html>
"""

LOGS_HTML = """
<!doctype html><html><head><meta charset="utf-8"><title>Intrusion Logs</title><style>
body{margin:0;font-family:system-ui,Arial;background:#0d1117;color:#e6edf3}header{padding:18px 24px;background:#161b22;display:flex;justify-content:space-between;border-bottom:1px solid #30363d}nav a{color:#8b949e;margin-left:18px;text-decoration:none}main{padding:24px}.card{background:#161b22;border:1px solid #30363d;border-radius:14px;padding:14px;margin-bottom:14px;display:grid;grid-template-columns:160px 1fr;gap:16px}img{width:160px;border-radius:10px;border:1px solid #30363d}.muted{color:#8b949e}</style></head><body>
<header><strong>Intrusion Logs</strong><nav><a href="/">Dashboard</a><a href="/configs">Configs</a><a href="/logs">Logs</a></nav></header><main id="logs"></main>
<script>
async function load(){const r=await fetch('/api/logs?limit=100');const rows=await r.json();const root=document.getElementById('logs');root.innerHTML='';rows.forEach(x=>{const div=document.createElement('div');div.className='card';div.innerHTML=`<div>${x.snapshot_path?`<img src="/media/${x.snapshot_path}">`:''}</div><div><h3>#${x.id} - ${x.camera_name||x.camera_id}</h3><p><b>Status:</b> ${x.status}</p><p><b>Start:</b> ${x.start_ts}<br><b>End:</b> ${x.end_ts||'Active'}<br><b>Duration:</b> ${x.duration_seconds ? x.duration_seconds.toFixed(1)+'s' : '—'}</p><p class="muted">Snapshot: ${x.snapshot_path||'—'}<br>Video: ${x.video_path||'—'}</p></div>`;root.appendChild(div)});}
load(); setInterval(load, 3000);
</script></body></html>
"""

CONFIGS_HTML = """
<!doctype html><html><head><meta charset="utf-8"><title>ROI Configs</title><style>
body{margin:0;font-family:system-ui,Arial;background:#0d1117;color:#e6edf3}header{padding:18px 24px;background:#161b22;display:flex;justify-content:space-between;border-bottom:1px solid #30363d}nav a{color:#8b949e;margin-left:18px;text-decoration:none}main{padding:24px}.card{background:#161b22;border:1px solid #30363d;border-radius:14px;padding:18px;margin-bottom:16px}button,select,input{background:#21262d;color:#e6edf3;border:1px solid #30363d;border-radius:8px;padding:9px 11px}canvas{max-width:100%;border:1px solid #30363d;border-radius:12px;background:#010409}.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}</style></head><body>
<header><strong>ROI Config Editor</strong><nav><a href="/">Dashboard</a><a href="/configs">Configs</a><a href="/logs">Logs</a></nav></header><main><section class="card"><div class="row"><select id="cam"></select><button onclick="loadFrame()">Grab Frame</button><input id="cfgName" placeholder="new_roi.yaml"><button onclick="saveRoi()">Save ROI</button><button onclick="points=[];draw()">Clear</button></div><p>Click the frame to create polygon points. Save creates a YAML config that can be selected on the dashboard.</p></section><canvas id="canvas"></canvas></main>
<script>
let img = new Image(); let points=[]; const canvas=document.getElementById('canvas'); const ctx=canvas.getContext('2d');
async function init(){const d=await (await fetch('/api/dashboard')).json();document.getElementById('cam').innerHTML=d.cameras.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');}
async function loadFrame(){const cam=document.getElementById('cam').value; img.src=`/api/cameras/${cam}/snapshot?t=${Date.now()}`; img.onload=()=>{canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;points=[];draw();};}
function draw(){ctx.clearRect(0,0,canvas.width,canvas.height); if(img.src) ctx.drawImage(img,0,0); ctx.lineWidth=3; ctx.strokeStyle='yellow'; ctx.fillStyle='red'; ctx.beginPath(); points.forEach((p,i)=>{if(i===0)ctx.moveTo(p[0],p[1]);else ctx.lineTo(p[0],p[1]); ctx.fillRect(p[0]-4,p[1]-4,8,8);}); if(points.length>2)ctx.closePath(); ctx.stroke();}
canvas.addEventListener('click', e=>{const r=canvas.getBoundingClientRect(); points.push([Math.round((e.clientX-r.left)*canvas.width/r.width), Math.round((e.clientY-r.top)*canvas.height/r.height)]); draw();});
async function saveRoi(){if(points.length<3){alert('Need at least 3 points');return;} const name=document.getElementById('cfgName').value; const r=await fetch('/api/configs/roi',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,points})}); if(!r.ok) alert(await r.text()); else alert('Saved');}
init();
</script></body></html>
"""


def build_app(config_path: str) -> FastAPI:
    config = load_yaml(config_path)
    app_cfg = config.get("app", {})
    os.makedirs(app_cfg.get("intruder_dir", "intruder"), exist_ok=True)
    os.makedirs(app_cfg.get("videos_dir", "videos"), exist_ok=True)
    db = IntrusionDB(app_cfg.get("database_path", "surveillance.db"))
    # Avoid stale active counts after a restart/crash; running state is owned by live workers.
    db.end_all_active()
    notifier = TelegramNotifier(config.get("telegram", {}))
    workers: Dict[str, CameraWorker] = {}
    for cam_cfg in config.get("cameras", []):
        worker = CameraWorker(cam_cfg, app_cfg, config.get("models", {}), db, notifier)
        workers[worker.camera_id] = worker
        # Do not start cameras just because the dashboard page loaded.
        # Set app.autostart_cameras: true if you explicitly want boot-time monitoring.
        if app_cfg.get("autostart_cameras", False) and cam_cfg.get("enabled", False):
            worker.start()

    app = FastAPI(title="Security Surveillance Dashboard")

    @app.on_event("shutdown")
    def shutdown() -> None:
        for worker in workers.values():
            worker.stop()

    @app.get("/", response_class=HTMLResponse)
    def dashboard() -> str:
        return DASHBOARD_HTML

    @app.get("/logs", response_class=HTMLResponse)
    def logs_page() -> str:
        return LOGS_HTML

    @app.get("/configs", response_class=HTMLResponse)
    def configs_page() -> str:
        return CONFIGS_HTML

    @app.get("/api/dashboard")
    def dashboard_data() -> Dict[str, Any]:
        cameras = []
        for worker in workers.values():
            cam = dict(worker.cfg)
            cam["status"] = worker.get_status()
            cameras.append(cam)
        return {
            "stats": db.stats(),
            "cameras": cameras,
            "models": list(config.get("models", {}).keys()),
            "roi_configs": sorted(str(p) for p in Path(".").glob("*.y*ml")),
        }

    @app.patch("/api/cameras/{camera_id}")
    def update_camera(camera_id: str, patch: CameraPatch) -> Dict[str, Any]:
        worker = workers.get(camera_id)
        if not worker:
            raise HTTPException(404, "Camera not found")
        data = patch.dict(exclude_unset=True)
        enabled = data.pop("enabled", None)
        worker.update_cfg(data)
        if enabled is True:
            # Runtime-only start: do not persist this as boot-time autostart.
            worker.cfg["enabled"] = True
            worker.start()
        elif enabled is False:
            worker.cfg["enabled"] = False
            worker.stop()
            db.end_active_for_camera(camera_id)
        save_yaml(config_path, config)
        return {"ok": True, "camera": worker.cfg, "status": worker.get_status()}

    @app.get("/api/cameras/{camera_id}/stream")
    def stream(camera_id: str):
        worker = workers.get(camera_id)
        if not worker:
            raise HTTPException(404, "Camera not found")

        def gen():
            last_seq = -1
            while True:
                frame, seq = worker.wait_for_frame(last_seq, timeout=1.0)
                if frame and seq != last_seq:
                    last_seq = seq
                    yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n"
                elif not worker.is_running():
                    break

        return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

    @app.get("/api/cameras/{camera_id}/snapshot")
    def snapshot(camera_id: str):
        worker = workers.get(camera_id)
        if not worker:
            raise HTTPException(404, "Camera not found")
        frame = worker.get_frame()
        if not frame:
            cap = cv2.VideoCapture(worker.cfg["source"])
            ret, img = cap.read()
            cap.release()
            if not ret:
                raise HTTPException(409, "No frame available. Start the camera or check the source.")
            ok, buffer = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
            if not ok:
                raise HTTPException(500, "Could not encode frame.")
            frame = buffer.tobytes()
        return StreamingResponse(iter([frame]), media_type="image/jpeg")

    @app.post("/api/configs/roi")
    def save_roi(req: RoiSaveRequest) -> Dict[str, Any]:
        try:
            filename = safe_name(req.name)
        except ValueError as exc:
            raise HTTPException(400, str(exc))
        if len(req.points) < 3:
            raise HTTPException(400, "ROI needs at least 3 points.")
        save_yaml(filename, {"roi_polygon": req.points})
        return {"ok": True, "path": filename}

    @app.get("/api/logs")
    def api_logs(limit: int = 100, camera_id: Optional[str] = None):
        return JSONResponse(db.list_intrusions(limit=limit, camera_id=camera_id))

    @app.get("/media/{path:path}")
    def media(path: str):
        normalized = os.path.normpath(path)
        if normalized.startswith(".."):
            raise HTTPException(400, "Invalid path")
        if not os.path.exists(normalized):
            raise HTTPException(404, "File not found")
        return FileResponse(normalized)

    return app


parser = argparse.ArgumentParser(description="Run the multi-camera surveillance dashboard")
parser.add_argument("--config", default="config.yaml", help="Main YAML config file")
args, _ = parser.parse_known_args()
app_config_path = args.config
app = build_app(app_config_path)

if __name__ == "__main__":
    cfg = load_yaml(app_config_path).get("app", {})
    uvicorn.run("surveillance_app:app", host=cfg.get("host", "0.0.0.0"), port=int(cfg.get("port", 8000)), reload=False)
